/**
 * @author Sharik
 * Test Case No: 1
 * Test Case Type: Sanity
 * Test Case Description: To verify the Name, Position and Description of Team Members on About Page
 * Module: 1.01
 * Release: 1808 
 */

package test.test;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.HomePage;
import utility.Constants;
import utility.ExcelUtils;
import utility.Log;



public class FirstTestCase {
	public static WebDriver driver;

	

	@BeforeTest
	public void PreReq() {
		System.setProperty("webdriver.chrome.driver", "D:\\Hp\\Selenium\\chromedriver.exe");
		DOMConfigurator.configure("log4j.xml");	
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(Constants.URL);

	}



@Test
public void TestCase1() throws Exception {
	 ExcelUtils.setExcelFile(Constants.Path_TestData + Constants.File_TestData,"Sheet1");
	
	DOMConfigurator.configure("log4j.xml");	
	driver.get(Constants.URL);
	Screen screen = new Screen();

	screen.click(HomePage.about_Btn(driver));
	Log.info("Flight Option selected from Main Menu");
	
	for(int i=1;i<=14;i++){
		
		
	//clicked on team member profiles	
	driver.findElement(By.xpath("//*[@id='page-about']/body/div[2]/article/div/section[5]/div[2]/div["+i+"]/a/img")).click();	
		
	//Get Team member Name
	String desc=driver.findElement(By.xpath("//*[@id='bio_view']/div/div[2]/div[2]/h3")).getText();
	//Write Team member Name
	ExcelUtils.setCellData(desc, i, 1);
	
	//Get Team member Position
	String desc1=driver.findElement(By.xpath("//*[@id='bio_view']/div/div[2]/div[2]/span")).getText();
	//Write Team member Name
	ExcelUtils.setCellData(desc1, i, 2);
	
	//Get Team member Postion Desc
	String desc2=driver.findElement(By.xpath("//*[@id='bio_view']/div/div[2]/div[2]/p[2]/text()")).getText();
	//Write Team member Postion Desc
	ExcelUtils.setCellData(desc2, i, 3);
	
	}
	
}
}

