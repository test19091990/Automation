package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	
	private static WebElement element = null;
	
	public static WebElement about_Btn(WebDriver driver){
		
		element = driver.findElement(By.xpath("//*[@id='page-home']/body/footer/div/div[1]/div[4]/ul/li[1]/a"));		
		return element;
	}
	
	
	
	public static WebElement home_Btn(WebDriver driver){
		
		element = driver.findElement(By.xpath("//*[@id='page-home']/body/nav/a"));
		return element;
	}
}
