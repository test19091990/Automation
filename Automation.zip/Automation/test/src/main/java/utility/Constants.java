
package utility;
 
   public class Constants {
 
      public static final String URL = "https://mailchimp.com/";

      public static final String Path_TestData = "C:\\Automation\\test\\src\\testData\\";
      								
      public static final String File_TestData = "TestData.xlsx";
 
   }